var voice = "";

wx. cloud. init()
const recorderManager = wx.getRecorderManager()//首先声明录音组件
var util = require('../../utils/util.js');
Page({
  data:{
    soundUrl:"",
    upload: "block", //显示上传图标
    uploadsuccess: "none", //隐藏上传成功图标
    start: "block", //显示开始图标
    stop: "none", //隐藏停止图标
  },
  play: function () { 
    wx.playVoice({
      filePath: voice
    })
    console.log('..play..')
  },
  start: function () {
    var that=this;
    console.log('..start..')
    that.setData({
      start: "none", 
      stop: "block", 
    })
    wx.startRecord({
      success: function (e) {
        voice = e.tempFilePath;
      }
    })
  },
  stop: function () {
    var that=this;
    wx.stopRecord();
    console.log('..stop..');
    that.setData({
      start: "block", 
      stop: "none", 
    })
  },
  upload:function(){
    var that=this;
    let timestamp = util.formatTime(new Date());//生成一个时间戳，用来生成文件名
    wx.cloud.uploadFile({
      cloudPath: "sounds/"+timestamp + '-'+ '.mp3',//上传至云存储
      filePath: voice,
      success: res => {
        console.log('上传成功', res)
        that.setData({
          soundUrl: res.fileID,//上传成功后，将生成的云文件ID返给data变量soundUrl
          upload: "none", //显示上传图标
          uploadsuccess: "block"//隐藏上传成功图标
        })
       
      },
    });

  }
  
})
