var voice = "";
const recorderManager = wx.getRecorderManager()//首先声明录音组件
var util = require('../../utils/util.js');
Page({
  data:{
    soundUrl:""
  },
  play: function () { 
    wx.playVoice({
      filePath: voice
    })
    console.log('..play..')
  },
  start: function () {
    wx.startRecord({
      success: function (e) {
        voice = e.tempFilePath;
        console.log('..start..')
      }
    })
  },
  stop: function () {
    wx.stopRecord();
    console.log('..stop..');
    let timestamp = util.formatTime(new Date());//生成一个时间戳，用来生成文件名
  },
  upload:function(){
    wx.cloud.uploadFile({
      cloudPath: "sounds/"+timestamp + '-'+ '.mp3',//上传至云存储
      filePath: tempFilePath,
      success: res => {
        console.log('上传成功', res)
        that.setData({
          soundUrl: res.fileID,//上传成功后，将生成的云文件ID返给data变量soundUrl
        })
      },
    })
  }
  
})