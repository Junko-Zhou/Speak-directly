//index.js
//获取应用实例
const app = getApp()
var util =require('../../utils/util.js');

//增加列表条目
function editArr(arr,i,editCnt){
  let newArr = arr,editingObj = newArr[i];   
    for (var x in editCnt){
      editingObj[x]= editCnt[x];
    }
  return newArr;
}
Page({
  data: {
    time:'',
    date:'',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    curIpt:'',
    showAll:true,
    lists:[],
    curRange:[],
    curBegin:0,
    curFinish:1,
    remind:[]
  },
  
  onLoad: function () 
  {
    var that = this;
    //获取之前保留在缓存里的数据
    wx.getStorage({
      success: function(res) {
        if(res.data){
           that.setData({
            lists:res.data
          })
        }
      } 
    })
    
  },
  
//获取当前时间
  d:function(options){
    var DATE = util.formatTime(new Date());
    this.setData({
      date:DATE,
    })
  },

//删除条目
//提示
  delRecord() {
        wx.showModal({
          title: '提示',
          content: '确定要删除这个录音记录吗？',
          showCancel: true,
          cancelText: '取消',
          cancelColor: '#000000',
          confirmText: '确定',
          confirmColor: '#46a6ff',
          success: function(res) {            
          }
        })
      },
//删除实现
    toDelete(e){
      let i = e.target.dataset.id,newLists = this.data.lists;
      newLists.map(function(l,index){
        if (l.id == i){      
          newLists.splice(index,1);
        }
      })   
      this.setData({
          lists:newLists
        })
    },

//获取用户信息
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  
})

