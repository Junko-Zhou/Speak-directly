var voice = "";//音频文件存储路径
wx. cloud. init()//云开发初始化
var util = require('../../utils/util.js');//调用头文件一样的作用，那个文件里有时间有关内容
Page({
  data:{//初始设置
    soundUrl:"",
    upload: "block", //显示上传图标
    uploadsuccess: "none", //隐藏上传成功图标
    start: "block", //显示开始图标
    stop: "none", //隐藏停止图标
    transformtotext:""
  },
  play: function () { //播放
    wx.playVoice({
      filePath: voice
    })
    console.log('..play..')
  },

  //开始录音
  start: function () {
    var that=this;
    console.log('..start..')
    that.setData({//按键显示变更
      start: "none", 
      stop: "block", 
    })
    wx.startRecord({//录音功能
      success: function (e) {
        voice = e.tempFilePath;
      }
    })
  },
  //停止录音
  stop: function () {
    var that=this;
    wx.stopRecord();//录音结束
    console.log('..stop..');
    that.setData({//按键显示变更
      start: "block", 
      stop: "none", 
    })
  },
  upload:function(){
    var that=this;
    let timestamp = util.formatTime(new Date());//生成一个时间戳，用来生成文件名
    wx.cloud.uploadFile({
      cloudPath: "sounds/"+timestamp + '-'+ '.mp3',//上传至云存储
      filePath: voice,
      success: res => {
        console.log('上传成功', res)
        that.setData({
          soundUrl: res.fileID,//上传成功后，将生成的云文件ID返给data变量soundUrl
          upload: "none", //显示上传图标
          uploadsuccess: "block"//隐藏上传成功图标
        })
      },
    });
    
  },

  send:function(){
    var that =this;
    var timestamp = Date.parse(new Date()); //当前时间戳 
    timestamp = timestamp / 1000; 
    wx.request({
     url:'https://asr.tencentcloudapi.com',//https://cvm.tencentcloudapi.com/
     data:{},
     //使用签名方法 v3 时，公共参数需要统一放到 HTTP Header 请求头部中
     header:{
       'Authorization':' TC3-HMAC-SHA256 Credential=AKIDabNsoUg70cqxnUS84i5D7lKcMegSpNRF/2020-12-15/asr/tc3_request,SignedHeaders=content-type;host, Signature=N2RhNjVlODFiMmFkNmQ3YzE5MmNkNzMyYTBkODE2Y2I3MWM3OGY1Mw%3D%3D',
       'Content-Type':'application/json, charset=utf-8',
       'EngSerViceType':'16k_zh',//引擎模型类型:非电话场景中文普通话通用
       'Host':'asr.tencentcloudapi.com',
       'ProjectId':0,              
       'SourceType':0,//语音数据来源。0：语音 URL；1：语音数据（post body）
       'SubServiceType':2,
       'Url':'https://7a31-z10-6-2glqdmbicaafaaaa-1303854148.tcb.qcloud.la/sounds/2020/12/14%2010%3A35%3A13-.mp3?sign=5487784f6927c8e9fcf56d0e2f4f053a&t=1607913334',//语音 URL，公网可下载。需进行urlencode编码。
       'UsrAudioKey':'0000',//util.formatTime(new Date()),//用户端对此任务的唯一标识，用户自助生成，用于用户查找识别结果,要求是string
       'VoiceFormat':'mp3',
       'X-TC-Action':'SentenceRecognition',
       'X-TC-Version':'2019-06-14',
       'X-TC-Timestamp':timestamp,
      },
     method:'POST',
     success: (result) => {
      console.log('success',result);

      that.setData({
        transformtotext:result
      })
      
      },
      fail:function (e) {
      },
      complete:function(e){
        console.log('complete');
      }
    
    })
  }
  
})
